import './Card.css';
import React, {useState} from 'react';
import { Link } from 'react-router-dom';
import { AiOutlineEdit } from 'react-icons/ai';
import Popup from 'reactjs-popup';
import Form from 'react-jsonschema-form';

const Card = ({ project: initialProject, color }) => {

  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [project, setProject] = useState(initialProject);
  const [popupStyle, setPopupStyle] = useState({ backgroundColor: 'inherit' });


  const handleEditClick = (event) => {
    event.preventDefault(); // Prevent default behavior (navigation)
    event.stopPropagation(); // Stop event propagation (to prevent parent link from navigating)
    setPopupStyle({ backgroundColor: color });
    setIsPopupOpen(true); // Open the popup
  };

  const schema = {
    type: 'object',
    properties: Object.entries(project).reduce((acc, [key, value]) => {
      acc[key] = { type: typeof value, title: key };
      return acc;
    }, {}),
  };

  // UI schema to customize the form layout
  const uiSchema = {
    // Customize the layout here...
  };

  const formData = Object.assign({}, project);

  // Form submission handler
  const onSubmit = ({ formData }) => {
    // Handle form submission (update project values)
    console.log(formData);
    setProject(formData);
    // Close the popup after submission
    setIsPopupOpen(false);
  };

  return (
    <div>
      <Link to={`/project/${project.id}`} style={{ textDecoration: 'none' }}>
        <div className="card" style={{ backgroundColor: color }} >
          <div className="edit-icon" onClick={handleEditClick}>
            <AiOutlineEdit />
          </div>
          <h2 className="title">{project.name}</h2>
          <div className="info-container">
            <div className="info-item">
              <div className="info-value">{project.userCount}</div>
              <div className="info-description">Users Count</div>
            </div>
            <div className="info-item">
              <div className="info-value">{project.dbCount}</div>
              <div className="info-description">DBs Connected</div>
            </div>
            <div className="info-item">
              <div className="info-value">{project.tableCount}</div>
              <div className="info-description">Tables Used</div>
            </div>
            <div className="info-item">
              <div className="info-value">{project.testCaseSuites}</div>
              <div className="info-description">Test Case Suites</div>
            </div>
            <div className="info-item">
              <div className="info-value">{project.postTestingActions}</div>
              <div className="info-description">Post Testing Actions</div>
            </div>
            <div className="info-item">
              <div className={`run-status ${project.runStatus.toLowerCase()}`}>{project.runStatus}</div>
              <div className="info-description">Run Status</div>
            </div>
          </div>
        </div>
      </Link>

      <Popup open={isPopupOpen} onClose={() => setIsPopupOpen(false)} contentStyle={popupStyle}>
          <Form schema={schema} uiSchema={uiSchema} formData={formData} onSubmit={onSubmit} />
      </Popup>
    </div>
  );
};

export default Card;
