import './App.css';
import React, { useState } from 'react';
import Card from './components/Card';

const projects = [
  {
    id: 1,
    name: 'Project 1',
    userCount: 10,
    dbCount: 3,
    tableCount: 20,
    testCaseSuites: 5,
    postTestingActions: 2,
    runStatus: "Failure"
  },
  {
    id: 2,
    name: 'Project 2',
    userCount: 10,
    dbCount: 3,
    tableCount: 20,
    testCaseSuites: 5,
    postTestingActions: 2,
    runStatus: "Running"
  },
  {
    id: 3,
    name: 'Project 3',
    userCount: 10,
    dbCount: 3,
    tableCount: 20,
    testCaseSuites: 5,
    postTestingActions: 2,
    runStatus: "Success"
  },
  {
    id: 4,
    name: 'Project 4',
    userCount: 10,
    dbCount: 3,
    tableCount: 20,
    testCaseSuites: 5,
    postTestingActions: 2,
    runStatus: "Running"
  },
  // Add more projects as needed
];

const pastelColors = [
  '#B19CD9', // Purple
  '#A7C5EB', // Blue
  '#E8BB97', // Orange
  '#9CC4C4', // Teal
  '#B5EAD7', // Green
  '#F5E1DA', // Peach
  '#FFD3B6', // Salmon
  '#F8B195', // Apricot
];

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const filteredProjects = projects.filter(project =>
    Object.values(project).some(value =>
      value.toString().toLowerCase().includes(searchTerm.toString().toLowerCase())
    )
  );
  return (
    <div className="App">
      <h1>Project Dashboard</h1>
      <input
        type="text"
        placeholder="Search projects..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <div className="card-container">
        {filteredProjects.map((project, index) => (
          <Card key={project.name} project={project}  color={pastelColors[index % pastelColors.length]} />
        ))}
      </div>
    </div>
  );
}

export default App;
